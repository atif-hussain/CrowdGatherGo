import json, numpy as np, soundfile as sf
from scipy.signal import resample_poly, butter, sosfilt

SR = 48000
tl = json.load(open('/home/claude/video/timeline.json'))
N = int((tl['total'] + 0.5) * SR)
rng = np.random.default_rng(7)

# ---------- voice ----------
vo = np.zeros(N)
for s in tl['scenes']:
    w, sr = sf.read(f"/home/claude/video/vo_{s['name']}.wav")
    w = resample_poly(w, SR, sr)
    i = int(s['vo_start'] * SR)
    vo[i:i + len(w)] += w[:N - i]
vo = vo / (np.max(np.abs(vo)) + 1e-9) * 0.89

# ---------- music ----------
def note(f, dur, kind='pad'):
    t = np.arange(int(dur * SR)) / SR
    if kind == 'pad':
        w = sum(np.sin(2 * np.pi * f * d * t + rng.random() * 6) for d in (0.997, 1.0, 1.003)) / 3
        w += 0.25 * np.sin(2 * np.pi * 2 * f * t)
        env = np.minimum(1, t / 0.8) * np.minimum(1, (dur - t) / 0.9)
    else:  # pluck
        w = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)
        env = np.exp(-t * 5.5) * np.minimum(1, t / 0.004)
    return w * env

m2f = lambda m: 440 * 2 ** ((m - 69) / 12)
BPM = 96; beat = 60 / BPM; bar = 4 * beat
chords = [[50, 57, 62, 66, 69, 76], [47, 54, 59, 62, 66, 73], [43, 55, 59, 62, 66, 71], [45, 52, 57, 61, 64, 69]]  # D, Bm, G, A
pad = np.zeros(N); arp = np.zeros(N); kick = np.zeros(N); hat = np.zeros(N)
nbars = int(tl['total'] / bar) + 2
for b in range(nbars):
    ch = chords[(b // 2) % 4]
    t0 = b * bar
    if b % 2 == 0:
        for m in ch[:4]:
            w = note(m2f(m), 2 * bar + 0.9, 'pad'); i = int(t0 * SR); pad[i:i + len(w)] += w[:max(0, N - i)] * 0.16
    for k in range(8):  # 8th-note arpeggio
        m = ch[2:][[0, 1, 2, 3, 2, 1, 3, 2][k]] + 12
        w = note(m2f(m), 0.7, 'pluck'); i = int((t0 + k * beat / 2) * SR)
        if i < N: arp[i:i + len(w)] += w[:N - i] * (0.07 if k % 2 == 0 else 0.045)
    for k in range(4):  # soft kick + hat
        i = int((t0 + k * beat) * SR)
        tt = np.arange(int(0.35 * SR)) / SR
        kw = np.sin(2 * np.pi * (48 + 70 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 9)
        if i < N: kick[i:i + len(kw)] += kw[:N - i] * 0.5
        j = int((t0 + k * beat + beat / 2) * SR)
        hw = rng.standard_normal(int(0.05 * SR)) * np.exp(-np.arange(int(0.05 * SR)) / SR * 90)
        if j < N: hat[j:j + len(hw)] += hw[:N - j] * 0.05
hat = sosfilt(butter(4, 7000, 'hp', fs=SR, output='sos'), hat)
pad = sosfilt(butter(2, 2500, 'lp', fs=SR, output='sos'), pad)

t = np.arange(N) / SR
def ramp(a, b): return np.clip((t - a) / (b - a), 0, 1)
starts = {s['name']: s['start'] for s in tl['scenes']}
end = tl['endcard']
# energy curve: pad+arp from start, beat enters at 'problem', drops in 'design' briefly, full in 'math', fades out at end
beat_gain = ramp(starts['problem'] - 0.5, starts['problem'] + 1.5) * (1 - 0.6 * ramp(starts['design'], starts['design'] + 1) * (1 - ramp(starts['math'] - 1, starts['math'])))
beat_gain *= 1 - ramp(starts['close'] + 2, end + 1.5)
music = pad * (0.6 + 0.4 * ramp(0, 3)) + arp * ramp(0.5, 3) + (kick + hat) * beat_gain
music *= np.minimum(1, t / 1.0) * (1 - ramp(tl['total'] - 2.5, tl['total']))

# ---------- sfx: whoosh at scene changes ----------
sfx = np.zeros(N)
for s in tl['scenes'][1:] + [{'start': end}]:
    i = int((s['start'] - 0.25) * SR); L = int(0.6 * SR)
    nz = rng.standard_normal(L); tt = np.arange(L) / L
    env = np.sin(np.pi * tt) ** 2
    sos = butter(2, [400, 3500], 'bp', fs=SR, output='sos')
    w = sosfilt(sos, nz) * env * 0.12
    sfx[i:i + L] += w[:N - i]
# door chime at design door highlights
ds = starts['design']
for k, tt0 in enumerate([5.3, 5.6, 5.9, 6.2]):
    w = note(m2f(81 + [0, 4, 7, 12][k]), 0.6, 'pluck') * 0.12; i = int((ds + tt0) * SR); sfx[i:i + len(w)] += w

# ---------- ducking ----------
env = np.abs(vo)
win = int(0.25 * SR); env = np.convolve(env, np.ones(win) / win, mode='same')
duck = 1 - 0.55 * np.clip(env / 0.05, 0, 1)
mix = vo + music * 0.55 * duck + sfx
mix = mix / np.max(np.abs(mix)) * 0.93
sf.write('/home/claude/video/mix.wav', np.stack([mix, mix], 1).astype(np.float32), SR)
print('ok', N / SR)
