import json, sys, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro

VOICE = sys.argv[1] if len(sys.argv) > 1 else "af_heart"
SPEED = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0

# One entry per scene. Numbers written out so the voice reads them naturally.
LINES = [
 ("hook",    "Cyberabad, nine A.M. Sixty-three percent of trips here are shorter than five kilometres. Yet most of them are made alone, on two wheels or four."),
 ("problem", "Since twenty eleven, Hyderabad added about sixty-four lakh daily trips. Nearly sixty-two lakh went to private vehicles. Public transport's share fell from forty-two to twenty-five percent."),
 ("why",     "People don't drive because they enjoy jams. They drive because shared transport has three gaps: too few buses, a missing last mile, and waits you can't predict."),
 ("stop",    "And every stop costs time. Steps to climb, narrow doors, a crowd squeezing past. Slow stops mean fewer trips per bus, so you need a bigger fleet to do the same job."),
 ("design",  "Metro-on-Wheels brings metro-style boarding to a twelve-metre bus. Floor, doors and platform, all at six hundred and fifty millimetres. Four wide doors, all on the kerb side. A wheelchair, a pram, a suitcase: just roll in, level."),
 ("dwell",   "Boarding drops to about thirty seconds. Stopping and starting, about a minute."),
 ("math",    "Take a five-kilometre shuttle, say, Raidurg Metro to the Financial District. Five minutes running, one minute stopping, half a minute boarding, each way. About thirteen minutes, round trip. Send a bus every minute: thirteen buses, ninety-two people each, every single minute. That's over five thousand people an hour, from one pair of platforms."),
 ("scale",   "Need more? Add bays and an aisle at each terminal, so buses slow down off the main road, and never cause a jam. In simulation, a twelve-bay terminal moves about twenty-four thousand people an hour."),
 ("green",   "No tunnels. No viaducts. Roads we already have, standard bus dimensions, and a pilot in months. Ninety-two people in one bus, instead of up to ninety-two vehicles. Cleaner air, cooler streets."),
 ("close",   "Metro frequency. Bus cost. Built in months, not years. Metro-on-Wheels, for the Cyberabad of the next twenty-five years."),
]

k = Kokoro("/home/claude/tts/kokoro.onnx", "/home/claude/tts/voices.bin")
out = {}
for name, text in LINES:
    s, sr = k.create(text, voice=VOICE, speed=SPEED, lang="en-us")
    s = np.asarray(s, dtype=np.float32)
    # trim leading/trailing silence
    a = np.abs(s); idx = np.where(a > 0.01)[0]
    s = s[max(0, idx[0]-int(0.03*sr)): idx[-1]+int(0.08*sr)]
    sf.write(f"/home/claude/video/vo_{name}.wav", s, sr)
    out[name] = round(len(s)/sr, 2)
    print(name, out[name])
json.dump(out, open("/home/claude/video/vo_durations.json", "w"), indent=1)
print("total", round(sum(out.values()), 2))
