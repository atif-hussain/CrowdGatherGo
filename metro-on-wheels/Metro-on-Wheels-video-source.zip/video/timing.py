import json, re
d=json.load(open('vo_durations.json'))
import importlib.util
src=open('vo.py').read()
lines=eval(src[src.index('LINES = [')+8: src.index(']\n\nk =')+1])
LEAD, GAP, TAIL = 0.8, 0.45, 3.6
t=LEAD; scenes=[]
for name,text in lines:
    dur=d[name]
    # captions: split into chunks <= 58 chars at sentence/comma/word boundaries
    sents=re.split(r'(?<=[.:?!,])\s+', text)
    chunks=[]; cur=''
    for s in sents:
        if len(cur)+len(s)+1<=58: cur=(cur+' '+s).strip()
        else:
            if cur: chunks.append(cur)
            while len(s)>58:
                cut=s.rfind(' ',0,58); chunks.append(s[:cut]); s=s[cut+1:]
            cur=s
    if cur: chunks.append(cur)
    tot=sum(len(c) for c in chunks); ct=t; caps=[]
    for c in chunks:
        cd=dur*len(c)/tot; caps.append([round(ct,3),round(ct+cd,3),c]); ct+=cd
    scenes.append(dict(name=name,vo_start=round(t,3),vo_dur=dur,caps=caps))
    t+=dur+GAP
t=t-GAP
for i,s in enumerate(scenes):
    s['start']= 0 if i==0 else round(scenes[i]['vo_start']-GAP*0.6,3)
for i,s in enumerate(scenes):
    s['end']= scenes[i+1]['start'] if i+1<len(scenes) else None
END_CARD=t+0.3
TOTAL=round(t+TAIL,3)
scenes[-1]['end']=round(END_CARD,3)
json.dump(dict(scenes=scenes,endcard=round(END_CARD,3),total=TOTAL),open('timeline.json','w'),indent=1)
for s in scenes: print(s['name'],s['start'],s['end'],len(s['caps']))
print('total',TOTAL)
