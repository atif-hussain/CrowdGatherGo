import json, sys, base64, subprocess, asyncio
from playwright.async_api import async_playwright

MODE = sys.argv[1]  # 'preview' or 'full'
FPS = 30
tl = json.load(open('/home/claude/video/timeline.json'))

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--allow-file-access-from-files', '--disable-web-security'])
        pg = await b.new_page(viewport={'width': 1920, 'height': 1080})
        msgs = []
        pg.on('console', lambda m: msgs.append(m.text))
        pg.on('pageerror', lambda e: msgs.append('ERR ' + str(e)))
        await pg.goto('file:///home/claude/video/anim.html')
        await pg.evaluate('tl => setup(tl)', tl)
        if MODE == 'preview':
            times = [float(v) for v in sys.argv[2].split(',')]
            for t in times:
                await pg.evaluate(f'render({t})')
                data = await pg.evaluate("document.getElementById('c').toDataURL('image/jpeg',0.85)")
                open(f'/home/claude/video/prev_{t:06.2f}.jpg', 'wb').write(base64.b64decode(data.split(',')[1]))
        else:
            n = int(tl['total'] * FPS)
            ff = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS), '-c:v', 'mjpeg', '-i', '-',
                                   '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '/home/claude/video/silent.mp4'], stdin=subprocess.PIPE)
            for i in range(n):
                await pg.evaluate(f'render({i / FPS})')
                data = await pg.evaluate("document.getElementById('c').toDataURL('image/jpeg',0.95)")
                ff.stdin.write(base64.b64decode(data.split(',')[1]))
                if i % 300 == 0: print('frame', i, '/', n, flush=True)
            ff.stdin.close(); ff.wait()
        print('\n'.join(msgs[:20]))
        await b.close()

asyncio.run(main())
