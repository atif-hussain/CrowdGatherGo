import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
        pg=await b.new_page(viewport={'width':3024,'height':7559})
        await pg.goto('file:///home/claude/poster/poster.html'); await pg.wait_for_timeout(500)
        # measure natural content height of page div children
        h=await pg.evaluate("""()=>{const pgEl=document.querySelector('.page');const kids=[...pgEl.children];const last=kids[kids.length-1];
          const spacer=kids[kids.length-2];return {spacer:spacer.getBoundingClientRect().height/3.7795, footBottom:last.getBoundingClientRect().bottom/3.7795}}""")
        print(h)
        await pg.pdf(path='poster.pdf',prefer_css_page_size=True,print_background=True)
        await b.close()
asyncio.run(main())
