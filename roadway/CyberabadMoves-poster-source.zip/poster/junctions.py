ROAD='<rect x="80" y="0" width="40" height="120" fill="#D9D6CE"/><rect x="0" y="40" width="200" height="40" fill="#D9D6CE"/>'
RED='<g stroke="#D0342C" stroke-width="7" stroke-linecap="round" opacity=".9"><line x1="45" y1="10" x2="155" y2="110"/><line x1="155" y1="10" x2="45" y2="110"/></g>'
def badge(n,cx=100,cy=60): return f'<circle cx="{cx}" cy="{cy}" r="11" fill="#2d3047"/><text x="{cx}" y="{cy+5}" font-size="14" font-weight="800" fill="#F5C24A" text-anchor="middle">{n}</text>'
def arrow(x1,y1,x2,y2,col,w=5,dash=''):
    import math
    a=math.atan2(y2-y1,x2-x1);hx=x2-9*math.cos(a);hy=y2-9*math.sin(a)
    p1=(hx+6*math.sin(a),hy-6*math.cos(a));p2=(hx-6*math.sin(a),hy+6*math.cos(a))
    d=f' stroke-dasharray="{dash}"' if dash else ''
    return f'<line x1="{x1}" y1="{y1}" x2="{hx:.1f}" y2="{hy:.1f}" stroke="{col}" stroke-width="{w}"{d}/><path d="M{x2} {y2} L{p1[0]:.1f} {p1[1]:.1f} L{p2[0]:.1f} {p2[1]:.1f}Z" fill="{col}"/>'
E_,G_,B_='#E8693C','#2E9E64','#15356B'
tiles=[
 ('4-way signal','Each arm waits ¾ of every cycle.',True,
  ROAD+arrow(108,118,108,84,E_)+arrow(92,2,92,36,E_)+arrow(2,68,72,68,E_)+arrow(198,52,128,52,E_)+badge(4)+RED),
 ('P-turn','Block + U-turn: longer trips, weaving.',True,
  ROAD+'<rect x="76" y="57" width="48" height="6" fill="#2d3047"/><path d="M112 118 V22 a12 12 0 0 0 -24 0 V48" fill="none" stroke="#E8693C" stroke-width="5"/>'+arrow(88,48,10,48,E_,5,'6 4')+RED),
 ('Turn bans + reroute','No right turns: crossing in just 2 phases.',False,
  ROAD+arrow(108,118,108,2,G_)+arrow(92,2,92,118,G_)+arrow(2,68,198,68,B_)+arrow(198,52,2,52,B_)+badge(2)+
  '<circle cx="160" cy="18" r="13" fill="#fff" stroke="#D0342C" stroke-width="3"/><path d="M155 24 V14 h9" fill="none" stroke="#2d3047" stroke-width="2.5"/><line x1="151" y1="9" x2="169" y2="27" stroke="#D0342C" stroke-width="3"/>'),
 ('One-way pair','Cut phases 4 → 3 → 2; even peak-hour only.',False,
  ROAD+arrow(100,118,100,2,G_,6)+arrow(2,60,198,60,G_,6)+badge(2,100,60)),
 ('Loop-back road','Inner one-way loop replaces right turns: signal-free.',False,
  ROAD+'<path d="M120 46 C150 46,165 30,160 18 C155 6,130 6,128 24 L126 38" fill="none" stroke="#2E9E64" stroke-width="5" stroke-dasharray="7 4"/>'+arrow(108,118,108,2,G_)+arrow(2,68,198,68,B_)+badge(0)),
 ('Metered roundabout','2-lane loop; signals only meter entry.',False,
  ROAD+'<circle cx="100" cy="60" r="34" fill="none" stroke="#9aa3b5" stroke-width="16"/><circle cx="100" cy="60" r="20" fill="#2E9E64" opacity=".85"/>'+
  '<path d="M100 26 A34 34 0 0 1 134 60" fill="none" stroke="#2E9E64" stroke-width="4"/><path d="M134 60 l-6 -9 l12 0z" fill="#2E9E64"/>'+
  ''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="{c}"/>' for x,y,c in [(100,118-16,"#2E9E64"),(100,16,"#D0342C"),(22,60,"#2E9E64"),(178,60,"#D0342C")])),
 ('Parallel U-turns','Many vehicles U-turn at once, lane by lane.',False,
  '<rect x="0" y="35" width="200" height="50" fill="#D9D6CE"/><rect x="0" y="58" width="60" height="4" fill="#2d3047"/><rect x="140" y="58" width="60" height="4" fill="#2d3047"/>'+
  ''.join(f'<path d="M{70+i*20} 78 a8 16 0 0 1 0 -32" fill="none" stroke="#2E9E64" stroke-width="4"/><path d="M{70+i*20} 46 l8 -4 l0 8z" fill="#2E9E64"/>' for i in range(3))+
  '<text x="100" y="108" font-size="11" fill="#2d3047" text-anchor="middle">bikes · cars · bus</text>'),
 ('Short signal cycles','Same total flow, shorter tailbacks.',False,
  '<circle cx="62" cy="60" r="36" fill="#fff" stroke="#2d3047" stroke-width="4"/><path d="M62 60 V32" stroke="#2d3047" stroke-width="4"/><path d="M62 60 L80 70" stroke="#E8693C" stroke-width="4"/>'+
  '<text x="150" y="52" font-size="18" font-weight="800" fill="#2E9E64" text-anchor="middle">100 s →</text><text x="150" y="80" font-size="22" font-weight="800" fill="#2E9E64" text-anchor="middle">30 s</text>'),
]
html=''
for title,cap,bad,svg in tiles:
    col='#D0342C' if bad else '#2E9E64'
    mark='✗' if bad else '✓'
    html+=f'''<div class="card" style="flex:0 0 calc(25% - 6mm);padding:5mm 6mm;{'background:#FBEDEC' if bad else ''}">
      <svg viewBox="0 0 200 120" style="width:100%;height:92mm">{svg}</svg>
      <div style="font-size:40pt;font-weight:800;margin-top:2mm;line-height:1.1"><span style="color:{col}">{mark}</span> {title}</div>
      <div class="cap" style="color:var(--ink)">{cap}</div></div>\n'''
open('tiles.html','w').write(html)
